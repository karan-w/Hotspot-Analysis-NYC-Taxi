package cse512

import org.apache.spark.sql.catalyst.expressions.DayOfYear

object HotzoneUtils {

  def ST_Contains(queryRectangle: String, pointString: String ): Boolean = {
    // YOU NEED TO CHANGE THIS PART
    val rectangleCoordinates = queryRectangle.split(',')

    val pointCoordinates = pointString.split(',')

    // Extract x and y values from the rectangleCoordinates array
    val x1 = rectangleCoordinates(0).toDouble
    val y1 = rectangleCoordinates(1).toDouble
    val x2 = rectangleCoordinates(2).toDouble
    val y2 = rectangleCoordinates(3).toDouble

    //Extract x and y of the pointCoordinates
    val x = pointCoordinates(0).toDouble
    val y = pointCoordinates(1).toDouble

    //Use helper functions to determine whether x and y of the point coordinates are between the rectangle coordinates
    if(isWithinX(x, x1, x2) && isWithinY(y, y1, y2)) {
      return true
    } else {
      return false
    }
  }

  // YOU NEED TO CHANGE THIS PART

  //Helper function to determine whether x of point coordinates is between x1 and x2 of the rectangle coordinates
  def isWithinX(x: Double, x1: Double, x2: Double): Boolean = {
    if ((x >= x1 && x <= x2) || (x >= x2 && x <= x1)) {
      return true
    } else {
      return false
    }
  }

  //Helper function to determine whether y of point coordinates is between y1 and y2 of the rectangle coordinates
  def isWithinY(y: Double, y1: Double, y2: Double): Boolean = {
    if ((y >= y1 && y <= y2) || (y >= y2 && y <= y1)) {
      return true
    } else {
      return false
    }
  }
}
