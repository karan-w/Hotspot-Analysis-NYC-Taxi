package cse512

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions._

object HotcellAnalysis {
  Logger.getLogger("org.spark_project").setLevel(Level.WARN)
  Logger.getLogger("org.apache").setLevel(Level.WARN)
  Logger.getLogger("akka").setLevel(Level.WARN)
  Logger.getLogger("com").setLevel(Level.WARN)

def runHotcellAnalysis(spark: SparkSession, pointPath: String): DataFrame =
{
  // Load the original data from a data source
  var pickupInfo = spark.read.format("com.databricks.spark.csv").option("delimiter",";").option("header","false").load(pointPath);
  pickupInfo.createOrReplaceTempView("nyctaxitrips")
  pickupInfo.show()

  // Assign cell coordinates based on pickup points
  spark.udf.register("CalculateX",(pickupPoint: String)=>((
    HotcellUtils.CalculateCoordinate(pickupPoint, 0)
    )))
  spark.udf.register("CalculateY",(pickupPoint: String)=>((
    HotcellUtils.CalculateCoordinate(pickupPoint, 1)
    )))
  spark.udf.register("CalculateZ",(pickupTime: String)=>((
    HotcellUtils.CalculateCoordinate(pickupTime, 2)
    )))
  pickupInfo = spark.sql("select CalculateX(nyctaxitrips._c5),CalculateY(nyctaxitrips._c5), CalculateZ(nyctaxitrips._c1) from nyctaxitrips")
  var newCoordinateName = Seq("x", "y", "z")
  pickupInfo = pickupInfo.toDF(newCoordinateName:_*)
  pickupInfo.show()

  // Define the min and max of x, y, z
  val minX = -74.50/HotcellUtils.coordinateStep
  val maxX = -73.70/HotcellUtils.coordinateStep
  val minY = 40.50/HotcellUtils.coordinateStep
  val maxY = 40.90/HotcellUtils.coordinateStep
  val minZ = 1
  val maxZ = 31
  val numCells = (maxX - minX + 1)*(maxY - minY + 1)*(maxZ - minZ + 1)

  // YOU NEED TO CHANGE THIS PART

  pickupInfo.createOrReplaceTempView("pickUpInfo")


  val pickUpPointsFrequencyQuery = """SELECT x, y, z, COUNT(*) as frequency FROM pickUpInfo
                                    WHERE x BETWEEN %f AND %f
                                    AND y BETWEEN %f AND %f
                                    AND z BETWEEN %d AND %d
                                    GROUP BY x, y, z
    """.format(minX, maxX, minY, maxY,minZ, maxZ)

  val pickUpPointsFrequencyDataFrame = spark.sql(pickUpPointsFrequencyQuery)

  pickUpPointsFrequencyDataFrame.createOrReplaceTempView("pickUpPointsFrequency")

  //Calculate sigma Xj and sigma (Xj)^2
  val totalFrequencyQuery = "SELECT SUM(frequency), SUM(frequency * frequency) FROM pickUpPointsFrequency"

  val totalFrequencyDataFrame = spark.sql(totalFrequencyQuery)

  // Reference - http://sigspatial2016.sigspatial.org/giscup2016/problem

  //Calculate X bar
  val xBar = totalFrequencyDataFrame
    .first() // Get the first row from the data frame
    .getLong(0) // Get the first column of the first row
    .toDouble/(numCells.toDouble)

  //Calculate S
  val sumFrequencySquared = totalFrequencyDataFrame
    .first()
    .getLong(1)
    .toDouble/(numCells.toDouble)

  val xBarSquared = scala.math.pow(xBar, 2)

  val S = Math.sqrt(sumFrequencySquared - xBarSquared)

  spark.udf.register("findNeighboursCount", (X: Double, Y: Double, Z: Int,
                                       minX: Double, maxX: Double,
                                       minY: Double, maxY: Double,
                                       minZ: Int, maxZ: Int)=>((
    HotcellUtils.findNeighboursCount(X, Y, Z, minX, maxX, minY, maxY, minZ, maxZ)
    )))

  val weight_ij_X_j_query = """SELECT findNeighboursCount( ppf1.x, ppf1.y, ppf1.z, %f, %f, %f, %f, %d, %d) AS weight_ij,
    SUM(ppf2.frequency) AS Xj, ppf1.x AS X, ppf1.y AS Y, ppf1.z AS Z
    FROM pickupPointsFrequency ppf1, pickupPointsFrequency ppf2
    WHERE (ppf2.x = ppf1.x OR ppf2.x = ppf1.x + 1 OR ppf2.x = ppf1.x - 1)
    AND (ppf2.y = ppf1.y OR ppf2.y = ppf1.y + 1 OR ppf2.y = ppf1.y - 1)
    AND (ppf2.z = ppf1.z OR ppf2.z = ppf1.z + 1 OR ppf2.z = ppf1.z - 1)
    GROUP BY ppf1.x, ppf1.y, ppf1.z
    """.format(minX, maxX, minY, maxY, minZ, maxZ)

  //Calculate Wij & Xj
  val weight_ij_X_j_data_frame = spark.sql(weight_ij_X_j_query)

  weight_ij_X_j_data_frame.createOrReplaceTempView("weight_ij_X_j_values")

  spark.udf.register("calculateG", (sumX: Double, xBar: Double, w: Double, s: Double, nCells: Double)=>((
    HotcellUtils.calculateG(sumX, xBar, w, s, nCells)
    )))

  val gStatisticQuery =
    """
       SELECT x, y, z, calculateG(Xj, %f, weight_ij, %f, %f) as G_statistic from weight_ij_X_j_values
    """.format(xBar, S, numCells.toDouble)

  val gStatisticDataFrame = spark.sql(gStatisticQuery)

  gStatisticDataFrame.createOrReplaceTempView("GettisOrd")

  val resultQuery =
    """
       SELECT x, y, z
       FROM GettisOrd
       ORDER BY G_statistic DESC limit 50
    """

  val resultDataFrame = spark.sql(resultQuery)

  return resultDataFrame // YOU NEED TO CHANGE THIS PART
}
}
